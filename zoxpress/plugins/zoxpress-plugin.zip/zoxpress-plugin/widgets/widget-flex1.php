<?php
add_action( 'widgets_init', 'zox_flex_list1_load_widgets' );

function zox_flex_list1_load_widgets() {
	register_widget( 'zox_flex_list1_widget' );
}

class zox_flex_list1_widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function __construct() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'zox_flex_list1_widget', 'description' => esc_html__('A widget that displays list of posts with flexible options.', 'zoxpress') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'zox_flex_list1_widget' );

		/* Create the widget. */
		parent::__construct( 'zox_flex_list1_widget', esc_html__('ZoxPress: Flexible List Widget', 'zoxpress'), $widget_ops, $control_ops );
	}

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		global $post;
		$title = apply_filters('widget_title', $instance['title'] );
		$number = $instance['number'];
		$content = $instance['content'];
		$rowcol = $instance['rowcol'];
		$columns = $instance['columns'];
		$enterslug = $instance['enterslug'];
		$exclude = $instance['exclude'];
		$code = $instance['code'];
		$adside = $instance['adside'];
		$bgcolor = $instance['bgcolor'];
		$txtcolor = $instance['txtcolor'];

		?>
			<?php if ($bgcolor == 'white') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgw zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgw">
				<?php } ?>
			<?php } else if ($bgcolor == 'gray') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgg zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgg">
				<?php } ?>
			<?php } else if ($bgcolor == 'black') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgb zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgb">
				<?php } ?>
			<?php } else if ($bgcolor == 'primary') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgp zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgp">
				<?php } ?>
			<?php } else if ($bgcolor == 'secondary') { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bgs zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg zox-widget-bgs">
				<?php } ?>
			<?php } else { ?>
				<?php if ($txtcolor == 'white') { ?>
					<div class="zox-widget-bg zox-widget-bg zox-widget-txtw">
				<?php } else { ?>
					<div class="zox-widget-bg">
				<?php } ?>
			<?php } ?>
		<?php

		/* Before widget (defined by themes). */
		echo html_entity_decode($before_widget);

		/* Display the widget title if one was input (before and after defined by themes). */
				if ( $title )
			echo html_entity_decode($before_title . $title . $after_title);

		?>
		<?php if ($adside == 'left') { ?>
			<div class="zox-widget-flex1-adl">
		<?php } else { ?>
			<div class="zox-widget-flex1-adr">
		<?php } ?>
			<?php if ($rowcol == 'rows') { ?>
				<?php if($code) { ?>
					<div class="zox-widget-flex1-wrap zox-divr zox-widget-flex1-ad">
				<?php } else { ?>
					<div class="zox-widget-flex1-wrap zox-divr">
				<?php } ?>
			<?php } else { ?>
				<?php if ($columns == '3') { ?>
					<?php if($code) { ?>
						<div class="zox-widget-flex1-wrap zox-widget-flex1-col zox-div3 zox-widget-flex1-ad">
					<?php } else { ?>
						<div class="zox-widget-flex1-wrap zox-widget-flex1-col zox-div3">
					<?php } ?>
				<?php } else { ?>
					<?php if($code) { ?>
						<div class="zox-widget-flex1-wrap zox-widget-flex1-col zox-div4 zox-widget-flex1-ad">
					<?php } else { ?>
						<div class="zox-widget-flex1-wrap zox-widget-flex1-col zox-div4">
					<?php } ?>
				<?php } ?>
			<?php } ?>
				<div class="zox-widget-flex1-cont zox100">
					<?php if ($content == 'category') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php if ($exclude) { ?>
								<?php global $do_not_duplicate; global $post; $count = 0; $recent = new WP_Query(array( 'category_name' => $enterslug, 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } else { ?>
								<?php global $do_not_duplicate; $count = 0; $recent = new WP_Query(array( 'category_name' => $enterslug, 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } ?>
						<?php } else { ?>
							<?php if ($exclude) { ?>
								<?php global $post; $count = 0; $recent = new WP_Query(array( 'category_name' => $enterslug, 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } else { ?>
								<?php $count = 0; $recent = new WP_Query(array( 'category_name' => $enterslug, 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } ?>
						<?php } ?>
					<?php } else if ($content == 'tag') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php if ($exclude) { ?>
								<?php global $do_not_duplicate; global $post; $count = 0; $recent = new WP_Query(array( 'tag' => $enterslug, 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } else { ?>
								<?php global $do_not_duplicate; $count = 0; $recent = new WP_Query(array( 'tag' => $enterslug, 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } ?>
						<?php } else { ?>
							<?php if ($exclude) { ?>
								<?php global $post; $count = 0; $recent = new WP_Query(array( 'tag' => $enterslug, 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $do_not_duplicate[] = $post->ID; $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } else { ?>
								<?php $count = 0; $recent = new WP_Query(array( 'tag' => $enterslug, 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); while($recent->have_posts()) : $recent->the_post(); $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; wp_reset_postdata(); ?>
							<?php } ?>
						<?php } ?>
					<?php } else { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php if ($exclude) { ?>
								<?php global $do_not_duplicate; global $post; $count = 0; query_posts(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; endif; wp_reset_query(); ?>
							<?php } else { ?>
								<?php global $do_not_duplicate; $count = 0; query_posts(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; endif; wp_reset_query(); ?>
							<?php } ?>
						<?php } else { ?>
							<?php if ($exclude) { ?>
								<?php global $post; $count = 0; query_posts(array( 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $do_not_duplicate[] = $post->ID; $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; endif; wp_reset_query(); ?>
							<?php } else { ?>
								<?php $count = 0; query_posts(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); $count++; ?>
									<?php if ($count == 1) { ?>
										<?php get_template_part( 'parts/art', 'midm' ); ?>
									<?php } else { ?>
										<?php get_template_part( 'parts/art', 'mid' ); ?>
									<?php } ?>
								<?php endwhile; endif; wp_reset_query(); ?>
							<?php } ?>
						<?php } ?>
					<?php } ?>
				</div><!--zox-widget-flex1-cont-->
				<?php if($code) { ?>
					<div class="zox-widget-side-ad zox-sticky-side">
						<div class="zox-widget-ad left zoxrel">
							<span class="zox-ad-label"><?php esc_html_e( 'Advertisement', 'zoxpress' ); ?></span>
							<?php echo do_shortcode(html_entity_decode($code)); ?>
						</div><!--zox-widget-ad-->
					</div><!--zox-widget-side-ad-->
				<?php } ?>
			</div><!--zox-widget-flex1-wrap-->
		</div><!--zox-widget-flex1-adl-->
		<?php

		/* After widget (defined by themes). */
		echo html_entity_decode($after_widget);

		?>
			</div><!--zox-widget-bg-->
		<?php

	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['number'] = strip_tags( $new_instance['number'] );
		$instance['content'] = strip_tags( $new_instance['content'] );
		$instance['rowcol'] = strip_tags( $new_instance['rowcol'] );
		$instance['columns'] = strip_tags( $new_instance['columns'] );
		$instance['enterslug'] = strip_tags( $new_instance['enterslug'] );
		$instance['exclude'] = strip_tags( $new_instance['exclude'] );
		$instance['code'] = $new_instance['code'];
		$instance['adside'] = strip_tags( $new_instance['adside'] );
		$instance['bgcolor'] = strip_tags( $new_instance['bgcolor'] );
		$instance['txtcolor'] = strip_tags( $new_instance['txtcolor'] );

		return $instance;
	}

	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 'title' => 'Latest', 'number' => '6', 'content' => 'latest', 'rowcol' => 'columns', 'columns' => '3', 'popular_days' => '30', 'exclude' => 'on', 'bgcolor' => 'none', 'txtcolor' => 'standard' );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'title' )); ?>">Title:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'title' )); ?>" value="<?php echo esc_html($instance['title']); ?>" style="width:90%;" />
		</p>

		<!-- Number of posts -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'number' )); ?>">Number of Posts to display:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'number' )); ?>" name="<?php echo esc_html($this->get_field_name( 'number' )); ?>" value="<?php echo esc_html($instance['number']); ?>" size="3" />
		</p>

		<!-- Content -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('content')); ?>">Choose Type of Content:</label>
			<select id="<?php echo esc_html($this->get_field_id('content')); ?>" name="<?php echo esc_html($this->get_field_name('content')); ?>" style="width:100%;">
				<option value='latest' <?php if ('latest' == $instance['content']) echo 'selected="selected"'; ?>>Latest</option>
				<option value='category' <?php if ('category' == $instance['content']) echo 'selected="selected"'; ?>>Category</option>
				<option value='tag' <?php if ('tag' == $instance['content']) echo 'selected="selected"'; ?>>Tag</option>
			</select>
		</p>

		<!-- Rows/Columns -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('rowcol')); ?>">Rows/Colums:</label>
			<select id="<?php echo esc_html($this->get_field_id('rowcol')); ?>" name="<?php echo esc_html($this->get_field_name('rowcol')); ?>" style="width:100%;">
				<option value='rows' <?php if ('rows' == $instance['rowcol']) echo 'selected="selected"'; ?>>Rows</option>
				<option value='columns' <?php if ('columns' == $instance['rowcol']) echo 'selected="selected"'; ?>>Columns</option>
			</select>
		</p>

		<!-- Columns -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('columns')); ?>">Number of Columns:</label>
			<select id="<?php echo esc_html($this->get_field_id('columns')); ?>" name="<?php echo esc_html($this->get_field_name('columns')); ?>" style="width:100%;">
				<option value='3' <?php if ('3' == $instance['columns']) echo 'selected="selected"'; ?>>3</option>
				<option value='4' <?php if ('4' == $instance['columns']) echo 'selected="selected"'; ?>>4</option>
			</select>
		</p>

		<!-- Enter Cat/Tag -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'enterslug' )); ?>">Enter Category/Tag Slug Name:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'enterslug' )); ?>" name="<?php echo esc_html($this->get_field_name( 'enterslug' )); ?>" value="<?php echo esc_html($instance['enterslug']); ?>" style="width:90%;" />
		</p>

		<!-- Exclude -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'exclude' )); ?>">Exclude posts on rest of page:</label>
			<input type="checkbox" id="<?php echo esc_html($this->get_field_id( 'exclude' )); ?>" name="<?php echo esc_html($this->get_field_name( 'exclude' )); ?>" <?php checked( (bool) esc_html($instance['exclude']), true ); ?> />
		</p>

		<!-- Ad Code -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'code' )); ?>">Widget Ad Code:</label>
			<textarea id="<?php echo esc_html($this->get_field_id( 'code' )); ?>" name="<?php echo esc_html($this->get_field_name( 'code' )); ?>" style="width:96%;" rows="6"><?php echo html_entity_decode($instance['code']); ?></textarea>
		</p>

		<!-- Ad Side -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('adside')); ?>">Ad on Right or Left:</label>
			<select id="<?php echo esc_html($this->get_field_id('adside')); ?>" name="<?php echo esc_html($this->get_field_name('adside')); ?>" style="width:100%;">
				<option value='right' <?php if ('right' == $instance['adside']) echo 'selected="selected"'; ?>>Right</option>
				<option value='left' <?php if ('left' == $instance['adside']) echo 'selected="selected"'; ?>>Left</option>
			</select>
		</p>

		<!-- Background Color -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('bgcolor')); ?>">Background Color:</label>
			<select id="<?php echo esc_html($this->get_field_id('bgcolor')); ?>" name="<?php echo esc_html($this->get_field_name('bgcolor')); ?>" style="width:100%;">
				<option value='none' <?php if ('none' == $instance['bgcolor']) echo 'selected="selected"'; ?>>None</option>
				<option value='white' <?php if ('white' == $instance['bgcolor']) echo 'selected="selected"'; ?>>White</option>
				<option value='gray' <?php if ('gray' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Gray</option>
				<option value='black' <?php if ('black' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Black</option>
				<option value='primary' <?php if ('primary' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Primary Theme Color</option>
				<option value='secondary' <?php if ('secondary' == $instance['bgcolor']) echo 'selected="selected"'; ?>>Secondary Theme Color</option>
			</select>
		</p>

		<!-- Text Color -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('txtcolor')); ?>">Widget Text Color:</label>
			<select id="<?php echo esc_html($this->get_field_id('txtcolor')); ?>" name="<?php echo esc_html($this->get_field_name('txtcolor')); ?>" style="width:100%;">
				<option value='standard' <?php if ('standard' == $instance['txtcolor']) echo 'selected="selected"'; ?>>Standard</option>
				<option value='white' <?php if ('white' == $instance['txtcolor']) echo 'selected="selected"'; ?>>White</option>
			</select>
		</p>

	<?php
	}
}

?>