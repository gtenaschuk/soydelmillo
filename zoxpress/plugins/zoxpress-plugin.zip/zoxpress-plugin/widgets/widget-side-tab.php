<?php
add_action( 'widgets_init', 'zox_side_tab_load_widgets' );

function zox_side_tab_load_widgets() {
	register_widget( 'zox_side_tab_widget' );
}

class zox_side_tab_widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function __construct() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'zox_side_tab_widget', 'description' => esc_html__('A tabbed widget that displays a Latest, Trending, Video, and/or Gallery posts for use in sidebar widget areas.', 'zoxpress') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 250, 'height' => 350, 'id_base' => 'zox_side_tab_widget' );

		/* Create the widget. */
		parent::__construct( 'zox_side_tab_widget', esc_html__('ZoxPress: Sidebar Tabber Widget', 'zoxpress'), $widget_ops, $control_ops );
	}

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		global $post;
		$first_title = $instance['first_title'];
		$first = $instance['first'];
		$second_title = $instance['second_title'];
		$second = $instance['second'];
		$third_title = $instance['third_title'];
		$third = $instance['third'];
		$popular_days = $instance['popular_days'];
		$number = $instance['number'];
		$images = $instance['images'];

		/* Before widget (defined by themes). */
		echo html_entity_decode($before_widget);

		?>

			<div class="zox-widget-tab-wrap left zoxrel">
				<div class="zox-widget-tab-head-wrap left zoxrel zox100">
					<ul class="zox-widget-tab-head left zoxrel zox100">
						<li class="zox-widget-tab-act"><a href="#zox-tab-col1"><span class="zox-widget-tab-but"><?php echo esc_html( $first_title ); ?></span></a></li>
						<li><a href="#zox-tab-col2"><span class="zox-widget-tab-but"><?php echo esc_html( $second_title ); ?></span></a></li>
						<?php if ($third_title && $third !== 'none') { ?>
							<li><a href="#zox-tab-col3"><span class="zox-widget-tab-but"><?php echo esc_html( $third_title ); ?></span></a></li>
						<?php } ?>
					</ul>
				</div><!--zox-widget-tab-head-wrap-->
				<div id="zox-tab-col1" class="zox-side-list-wrap left zoxrel zox-tab-col-cont">
					<?php if ($first == 'latest') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'paged' =>$paged, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'posts_per_page' => $number, 'paged' =>$paged, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else if ($first == 'trending') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } else { ?>
							<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } ?>
					<?php } else if ($first == 'video') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else if ($first == 'gallery') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } ?>
				</div><!--zox-side-list-wrap-->
				<div id="zox-tab-col2" class="zox-side-list-wrap zoxl zoxrel zox-tab-col-cont">
					<?php if ($second == 'latest') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'paged' =>$paged, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'posts_per_page' => $number, 'paged' =>$paged, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else if ($second == 'trending') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } else { ?>
							<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } ?>
					<?php } else if ($second == 'video') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else if ($second == 'gallery') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } ?>
				</div><!--zox-side-list-wrap-->
				<?php if ($third !== 'none') { ?>
					<div id="zox-tab-col3" class="zox-side-list-wrap zoxl zoxrel zox-tab-col-cont">
					<?php if ($third == 'latest') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'paged' =>$paged, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'posts_per_page' => $number, 'paged' =>$paged, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else if ($third == 'trending') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } else { ?>
							<?php $popular_days_ago = "$popular_days days ago"; $recent = new WP_Query(array( 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1, 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'post_views_count', 'date_query' => array( array( 'after' => $popular_days_ago )) )); while($recent->have_posts()) : $recent->the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; wp_reset_postdata(); ?>
						<?php } ?>
					<?php } else if ($third == 'video') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-video' )), 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } else if ($third == 'gallery') { ?>
						<?php global $do_not_duplicate; if (isset($do_not_duplicate)) { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => $number, 'post__not_in'=>$do_not_duplicate, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } else { ?>
							<?php query_posts(array( 'tax_query' => array( array( 'taxonomy' => 'post_format', 'field' => 'slug', 'terms' => 'post-format-gallery' )), 'posts_per_page' => $number, 'ignore_sticky_posts'=> 1 )); if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php if($images) { ?>
									<?php get_template_part( 'parts/art', 'small' ); ?>
								<?php } else { ?>
									<article class="zox-art-wrap zox-tab-noimg zoxrel">
										<?php get_template_part( 'parts/art', 'text3' ); ?>
									</article><!--zox-art-wrap-->
								<?php } ?>
							<?php endwhile; endif; wp_reset_query(); ?>
						<?php } ?>
					<?php } ?>
				</div><!--zox-side-list-wrap-->
				<?php } ?>
			</div><!--zox-widget-tab-wrap-->

		<?php

		/* After widget (defined by themes). */
		echo html_entity_decode($after_widget);

	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['first_title'] = strip_tags( $new_instance['first_title'] );
		$instance['first'] = strip_tags( $new_instance['first'] );
		$instance['second_title'] = strip_tags( $new_instance['second_title'] );
		$instance['second'] = strip_tags( $new_instance['second'] );
		$instance['third_title'] = strip_tags( $new_instance['third_title'] );
		$instance['third'] = strip_tags( $new_instance['third'] );
		$instance['popular_days'] = strip_tags( $new_instance['popular_days'] );
		$instance['number'] = strip_tags( $new_instance['number'] );
		$instance['images'] = $new_instance['images'];

		return $instance;
	}


	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 'first_title' => 'Latest','first' => 'latest','second_title' => 'Trending','second' => 'trending','third_title' => 'Videos','third' => 'video', 'popular_days' => '30', 'number' => '8', 'images' => 'on' );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- First Title -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'first_title' )); ?>">First Column Title:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'first_title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'first_title' )); ?>" value="<?php echo esc_html($instance['first_title']); ?>" style="width:90%;" />
		</p>

		<!-- First Column -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('first')); ?>">Display In First Column:</label>
			<select id="<?php echo esc_html($this->get_field_id('first')); ?>" name="<?php echo esc_html($this->get_field_name('first')); ?>" style="width:100%;">
				<option value='latest' <?php if ('latest' == $instance['first']) echo 'selected="selected"'; ?>>Latest</option>
				<option value='trending' <?php if ('trending' == $instance['first']) echo 'selected="selected"'; ?>>Trending</option>
				<option value='video' <?php if ('video' == $instance['first']) echo 'selected="selected"'; ?>>Videos</option>
				<option value='gallery' <?php if ('gallery' == $instance['first']) echo 'selected="selected"'; ?>>Galleries</option>
			</select>
		</p>

		<!-- Second Title -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'second_title' )); ?>">Second Column Title:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'second_title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'second_title' )); ?>" value="<?php echo esc_html($instance['second_title']); ?>" style="width:90%;" />
		</p>

		<!-- Second Column -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('second')); ?>">Display In Second Column:</label>
			<select id="<?php echo esc_html($this->get_field_id('second')); ?>" name="<?php echo esc_html($this->get_field_name('second')); ?>" style="width:100%;">
				<option value='latest' <?php if ('latest' == $instance['second']) echo 'selected="selected"'; ?>>Latest</option>
				<option value='trending' <?php if ('trending' == $instance['second']) echo 'selected="selected"'; ?>>Trending</option>
				<option value='video' <?php if ('video' == $instance['second']) echo 'selected="selected"'; ?>>Videos</option>
				<option value='gallery' <?php if ('gallery' == $instance['second']) echo 'selected="selected"'; ?>>Galleries</option>
			</select>
		</p>

		<!-- Third Title -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'third_title' )); ?>">Third Column Title:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'third_title' )); ?>" name="<?php echo esc_html($this->get_field_name( 'third_title' )); ?>" value="<?php echo esc_html($instance['third_title']); ?>" style="width:90%;" />
		</p>

		<!-- Third Column -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id('third')); ?>">Display In Second Column:</label>
			<select id="<?php echo esc_html($this->get_field_id('third')); ?>" name="<?php echo esc_html($this->get_field_name('third')); ?>" style="width:100%;">
				<option value='latest' <?php if ('latest' == $instance['third']) echo 'selected="selected"'; ?>>Latest</option>
				<option value='trending' <?php if ('trending' == $instance['third']) echo 'selected="selected"'; ?>>Trending</option>
				<option value='video' <?php if ('video' == $instance['third']) echo 'selected="selected"'; ?>>Videos</option>
				<option value='gallery' <?php if ('gallery' == $instance['third']) echo 'selected="selected"'; ?>>Galleries</option>
				<option value='none' <?php if ('none' == $instance['third']) echo 'selected="selected"'; ?>>None</option>
			</select>
		</p>

		<!-- Number of days -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'popular_days' )); ?>">Number of days to use for Popular Posts:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'popular_days' )); ?>" name="<?php echo esc_html($this->get_field_name( 'popular_days' )); ?>" value="<?php echo esc_html($instance['popular_days']); ?>" size="3" />
		</p>

		<!-- Number of posts -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'number' )); ?>">Number of posts to display:</label>
			<input id="<?php echo esc_html($this->get_field_id( 'number' )); ?>" name="<?php echo esc_html($this->get_field_name( 'number' )); ?>" value="<?php echo esc_html($instance['number']); ?>" size="3" />
		</p>

		<!-- Images -->
		<p>
			<label for="<?php echo esc_html($this->get_field_id( 'images' )); ?>">Show Images:</label>
			<input type="checkbox" id="<?php echo esc_html($this->get_field_id( 'images' )); ?>" name="<?php echo esc_html($this->get_field_name( 'images' )); ?>" <?php checked( (bool) esc_html($instance['images']), true ); ?> />
		</p>

	<?php
	}
}

?>